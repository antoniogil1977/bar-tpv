BAR TPV - primera versión web para iPad

Abre index.html en un navegador compatible.
Los datos se guardan localmente en el dispositivo.

Para instalarla como app en iPad cuando esté publicada:
Safari -> Compartir -> Añadir a pantalla de inicio.

Incluye:
- Barra
- Mesas 1-12
- Varios clientes por mesa
- Cobro individual en efectivo manteniendo la mesa abierta
- Productos/precios uno a uno
- Caja del día
